import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";
import { Group, LoadingManager, Matrix4, Vector3 } from "three";
import { FBXLoader } from "three/examples/jsm/loaders/FBXLoader.js";
import { applyContactMotion, buildRig, restoreNeutralPose } from "../src/features/game/characters/Monkey";
import { createVineWalk, sampleVineWalkPose, sampleWalkingVine, stepVineWalk, vineWalkInput, VINE_WALK_LENGTH } from "../src/features/game/characters/vineWalking";
import { PHASE_FOUR_LADDER_SITE, PHASE_FOUR_FEET_OFFSET } from "../src/features/game/world/phaseFourLayout";
import { climbingPosition, nearestArborealInteraction } from "../src/features/game/world/forestLayout";

const site = PHASE_FOUR_LADDER_SITE;
test("both decks offer the rope interaction, but the floor beneath does not", () => {
  for (const end of [0, 1]) {
    const p = climbingPosition(site, end);
    assert.equal(nearestArborealInteraction(p, [site])?.site.id, site.id);
    assert.equal(nearestArborealInteraction({ ...p, y: -3 }, [site]), undefined);
    assert.ok(Math.abs(sampleWalkingVine(end * VINE_WALK_LENGTH).y + PHASE_FOUR_FEET_OFFSET - p.y) < 0.001);
  }
});

test("camera-relative W/S reverses with camera heading throughout the route", () => {
  for (let d = 0; d <= VINE_WALK_LENGTH; d += 0.25) {
    assert.ok(vineWalkInput(d, 0, 1, 0) > 0);
    assert.ok(vineWalkInput(d, 0, -1, 0) < 0);
    assert.ok(vineWalkInput(d, Math.PI, 1, 0) < 0);
    assert.ok(vineWalkInput(d, Math.PI, -1, 0) > 0);
    assert.equal(vineWalkInput(d, 0, 0, 0), 0);
  }
});

test("walk can pause, reverse mid-route, reach the top and return to the arrival deck", () => {
  const walk = createVineWalk(climbingPosition(site, 0), false);
  for (let i = 0; i < 180; i++) stepVineWalk(walk, 1, 1 / 60);
  for (let i = 0; i < 30; i++) stepVineWalk(walk, 0, 1 / 60);
  const stopped = walk.position.clone();
  for (let i = 0; i < 120; i++) stepVineWalk(walk, 0, 1 / 60);
  assert.ok(stopped.distanceTo(walk.position) < 1e-9);
  const distance = walk.distance;
  for (let i = 0; i < 30; i++) stepVineWalk(walk, -1, 1 / 60);
  assert.ok(walk.distance < distance);
  for (const direction of [1, -1] as const) {
    let arrived = false;
    for (let i = 0; i < 1500 && !arrived; i++) arrived = stepVineWalk(walk, direction, 1 / 60);
    assert.equal(arrived, true);
    assert.equal(walk.distance, direction > 0 ? VINE_WALK_LENGTH : 0);
  }
});

test("actual FBX hands and feet reach the rope in both directions without stretching", () => {
  globalThis.document ??= { createElementNS: () => ({ addEventListener() {}, removeEventListener() {}, setAttribute() {} }) } as unknown as Document;
  const bytes = readFileSync("public/assets/models/monkey.fbx");
  const template = new FBXLoader(new LoadingManager().setURLModifier(() => "")).parse(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength), "");
  const rig = buildRig(template, 1);
  const parent = new Group();
  parent.add(rig.model);
  const walk = createVineWalk(climbingPosition(site, 0), false);
  const point = (bone: typeof rig.bones.handL) => bone!.getWorldPosition(new Vector3());
  const armLength = point(rig.bones.armL).distanceTo(point(rig.bones.forearmL));
  for (const direction of [1, -1] as const) for (let d = 0.8; d < VINE_WALK_LENGTH - 0.8; d += 0.13) {
    walk.distance = d;
    walk.direction = direction;
    sampleVineWalkPose(walk);
    parent.position.copy(walk.position);
    parent.quaternion.setFromRotationMatrix(new Matrix4().makeBasis(new Vector3().copy(walk.basis.right).negate(), new Vector3().copy(walk.basis.up), new Vector3().copy(walk.basis.forward)));
    restoreNeutralPose(rig);
    parent.updateMatrixWorld(true);
    applyContactMotion(rig, "vine-walk", d, 1 / 60, { speed: 2, grounded: false, vineWalk: walk });
    parent.updateMatrixWorld(true);
    for (const [bone, target] of [[rig.bones.handL, walk.leftHand], [rig.bones.handR, walk.rightHand], [rig.bones.footL, walk.leftFoot], [rig.bones.footR, walk.rightFoot]] as const) {
      const error = point(bone).distanceTo(target);
      assert.ok(error < 0.035, `${bone?.name} dir=${direction} distance=${d}: contact error ${error}`);
    }
    assert.ok(Math.abs(point(rig.bones.armL).distanceTo(point(rig.bones.forearmL)) - armLength) < 1e-6);
  }
});
